library(testthat)
library(MSinco)

test_check("MSinco")
