// Bind enter key to runButton
$(document).keyup(function(event) {
    if ((event.key == "Enter")) {
        $("#run1").click();
    }
 });

$(document).keyup(function(event) {
    if ((event.key == "Enter")) {
        $("#run2").click();
    }
 });
 
 $(document).keyup(function(event) {
    if ((event.key == "Enter")) {
        $("#run3").click();
    }
 });
 
